import { getStore } from "@netlify/blobs";
import { createHmac } from "node:crypto";

const authed = (req) => !process.env.STAFF_KEY || req.headers.get("x-staff-key") === process.env.STAFF_KEY;
const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json" } });


const PS = "https://api.paystack.co";
const nights = (a, b) => Math.max(1, Math.round((new Date(b) - new Date(a)) / 864e5));
const balanceUsd = (s, r) => {
  const rm = s.rooms.find((x) => x.id == r.room);
  const sub = nights(r.in, r.out) * rm.rate + r.charges.reduce((t, c) => t + c.a, 0);
  return Math.max(0, sub * 1.1 - r.paid);
};
// Idempotent: each Paystack reference is counted once.
async function applyPayment(store, id, ref, usd) {
  const s = JSON.parse((await store.get("state")) || "null");
  const r = s && s.res.find((x) => x.id == id);
  if (!r) return false;
  r.pays = r.pays || [];
  if (r.pays.includes(ref)) return true;
  r.pays.push(ref);
  r.paid = Math.round((r.paid + usd) * 100) / 100;
  r.log.push(`${new Date().toLocaleString()} · Paystack payment $${usd.toFixed(2)} (${ref})`);
  await store.set("state", JSON.stringify(s));
  return true;
}

function parseIcs(txt) {
  const lines = txt.replace(/\r?\n[ \t]/g, "").split(/\r?\n/), out = [];
  let ev = null;
  const d = (v) => { const m = (v || "").match(/(\d{4})(\d{2})(\d{2})/); return m ? `${m[1]}-${m[2]}-${m[3]}` : ""; };
  for (const l of lines) {
    if (l.startsWith("BEGIN:VEVENT")) ev = {};
    else if (l.startsWith("END:VEVENT") && ev) { if (ev.start && ev.end) out.push(ev); ev = null; }
    else if (ev) {
      const [k, ...r] = l.split(":"), v = r.join(":"), key = k.split(";")[0];
      if (key === "DTSTART") ev.start = d(v);
      if (key === "DTEND") ev.end = d(v);
      if (key === "UID") ev.uid = v;
      if (key === "SUMMARY") ev.summary = v.replace(/\\,/g, ",");
    }
  }
  return out;
}

export default async (req) => {
  const store = getStore("staydesk");
  const p = new URL(req.url).pathname;
  const key = process.env.PAYSTACK_SECRET;

  // Public: Paystack calls this after a successful payment (signature-checked).
  if (p.endsWith("/paystack-webhook") && req.method === "POST") {
    const raw = await req.text();
    const sig = createHmac("sha512", key || "").update(raw).digest("hex");
    if (!key || sig !== req.headers.get("x-paystack-signature")) return json({ error: "bad signature" }, 401);
    const ev = JSON.parse(raw);
    if (ev.event === "charge.success" && ev.data.currency === "USD")
      await applyPayment(store, ev.data.metadata?.res_id, ev.data.reference, ev.data.amount / 100);
    return json({ ok: true });
  }

  if (!authed(req)) return json({ error: "unauthorized" }, 401);

  // Staff: create a USD payment link for a booking's outstanding balance.
  if (p.endsWith("/pay/init") && req.method === "POST") {
    if (!key) return json({ error: "Set PAYSTACK_SECRET" }, 501);
    const { id } = await req.json();
    const s = JSON.parse((await store.get("state")) || "null");
    const r = s && s.res.find((x) => x.id == id);
    if (!r) return json({ error: "booking not found" }, 404);
    const bal = balanceUsd(s, r);
    if (bal < 0.5) return json({ error: "Nothing to pay" }, 400);
    const res = await fetch(PS + "/transaction/initialize", {
      method: "POST",
      headers: { Authorization: "Bearer " + key, "content-type": "application/json" },
      body: JSON.stringify({
        email: r.email || "guest@example.com",
        amount: Math.round(bal * 100),
        currency: "USD",
        reference: `sd-${r.id}-${Date.now()}`,
        callback_url: new URL(req.url).origin + "/thanks.html",
        metadata: { res_id: r.id },
      }),
    });
    const d = await res.json();
    if (!d.status) return json({ error: d.message || "Paystack error (is USD enabled on your account?)" }, 502);
    return json({ url: d.data.authorization_url, amount: bal });
  }

  if (p.endsWith("/state")) {
    if (req.method === "PUT") { await store.set("state", await req.text()); return json({ ok: true }); }
    return new Response((await store.get("state")) || "null", { headers: { "content-type": "application/json" } });
  }

  if (p.endsWith("/fetch-ical") && req.method === "POST") {
    const { url } = await req.json();
    if (!/^https:\/\//i.test(url || "")) return json({ error: "https URL required" }, 400);
    const r = await fetch(url, { signal: AbortSignal.timeout(10000) });
    if (!r.ok) return json({ error: "feed returned " + r.status }, 502);
    return json(parseIcs(await r.text()));
  }

  if (p.endsWith("/send") && req.method === "POST") {
    const { via, to, subject, text } = await req.json();
    const e = process.env;
    if (via === "email") {
      if (!e.SENDGRID_KEY || !e.MAIL_FROM) return json({ error: "Set SENDGRID_KEY and MAIL_FROM" }, 501);
      const r = await fetch("https://api.sendgrid.com/v3/mail/send", {
        method: "POST",
        headers: { Authorization: "Bearer " + e.SENDGRID_KEY, "content-type": "application/json" },
        body: JSON.stringify({ personalizations: [{ to: [{ email: to }] }], from: { email: e.MAIL_FROM }, subject: subject || "Your stay", content: [{ type: "text/plain", value: text }] }),
      });
      return json({ ok: r.ok }, r.ok ? 200 : 502);
    }
    if (!e.TWILIO_SID || !e.TWILIO_TOKEN || !e.TWILIO_FROM) return json({ error: "Set TWILIO_SID, TWILIO_TOKEN, TWILIO_FROM" }, 501);
    const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${e.TWILIO_SID}/Messages.json`, {
      method: "POST",
      headers: { Authorization: "Basic " + btoa(e.TWILIO_SID + ":" + e.TWILIO_TOKEN), "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ To: to, From: e.TWILIO_FROM, Body: text }),
    });
    return json({ ok: r.ok }, r.ok ? 200 : 502);
  }
  return json({ error: "not found" }, 404);
};

export const config = { path: "/api/*" };
