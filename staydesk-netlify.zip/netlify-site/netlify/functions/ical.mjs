import { getStore } from "@netlify/blobs";

// Public feed per room: /ical/room-101.ics  (add ?t=ICAL_TOKEN if you set that env var)
export default async (req) => {
  const u = new URL(req.url);
  if (process.env.ICAL_TOKEN && u.searchParams.get("t") !== process.env.ICAL_TOKEN) return new Response("forbidden", { status: 403 });
  const room = (u.pathname.match(/room-(\d+)/) || [])[1];
  const s = JSON.parse((await getStore("staydesk").get("state")) || "null");
  if (!room || !s) return new Response("not found", { status: 404 });
  const c = (d) => d.replace(/-/g, "");
  const ev = s.res
    .filter((r) => r.room == room && r.status !== "cancel" && r.status !== "out")
    .map((r) => `BEGIN:VEVENT\r\nUID:staydesk-${r.id}@staydesk\r\nDTSTAMP:${new Date().toISOString().replace(/[-:]/g, "").slice(0, 15)}Z\r\nDTSTART;VALUE=DATE:${c(r.in)}\r\nDTEND;VALUE=DATE:${c(r.out)}\r\nSUMMARY:Reserved\r\nEND:VEVENT`);
  return new Response(`BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//StayDesk//EN\r\n${ev.join("\r\n")}\r\nEND:VCALENDAR`, { headers: { "content-type": "text/calendar; charset=utf-8" } });
};

export const config = { path: "/ical/*" };
